const mongoose = require('mongoose')

const elevesSchema= new mongoose.Schema({
    nom :{type:String, require},
    prenom :{type: String, require},
    email:{type: String, require},
    tel :{type: Number, require},
    token:{type: String},
    compteurMinutes:{type: Number, default: 10},
    dateFreeMin:{type: Date,default: Date.now},
    role:{type: String, default: 'registred'},
    dateCreation: {type:Date, default: Date.now}
}) 

const EleveModel = mongoose.model('Eleve', elevesSchema)

module.exports=EleveModel
