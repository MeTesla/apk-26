
 export const ordreEventsData = [
    `La description de « DAR CHOUAFA » et ses locataires.`,
    `Une séance au Bain maure.`,
    `La dispute de RAHMA avec Lalla Zoubida.`,
    `Lalla Aïcha et Lalla Zoubida se rendent avec sidi Mohammed à Sidi Ali Boughaleb.`,
    `Au sanctuaire de Sidi Ali Boughaled, le narrateur se fait griffer par un chat`,
    /* `Sidi Mohamed tombe malade.`,*/
    `Fatma Bziouya  achète une lampe à pétrole.`,
    `La disparition de Zineb.`,
    `Rahma organise un repas pour les mendiants aveugles.`,
    `Lalla Aïcha aide son mari en vendant ses bijoux.`,
    `La mort du coiffeur Sidi Mohamed Ben Tahar.`,
  
    `Nettoyage du Msid et fierté du Narrateur nommé «chef des frotteurs».`,
    `L’achat des habits neufs de la « kissarya ».`,
    `L’histoire de l’oncle Othman marié à une très jeune fille.`,
  
    `Deux jours avant Achoura et les préparatifs commencent.`,
    `Le réveil tôt du garçon, coupe de cheveux et la douche nocturne.`,
    `Le jour de Achoura, au msid, les enfants psalmodient.`,
    
    `Querelle du père avec un courtier au souk des bijoux.`,
    `Moulay Larbi, le mari de Lalla Aicha épouse une seconde femme.`,
    /*`Le Narrateur tombe malade.`*/
  
    `Le père a perdu son maigre capital, il décide de partir travailler comme moissonneur.`,
    `Le départ de Maâlem Abdeslam et ses conséquence : solitude, visite des sanctuaires.`,
  
    `Le Narrateur, sa mère, Lalla Aicha vont chez Sidi El Arafi.`,
    `La mère décide de retenir l'enfant à la maison.`,
    `La visite d'un messager de la part du père. Il apporte des provisions et une petite somme d'argent`,
   
    `Salama, la marieuse annonce le divorce de Moulay Larbi et la fille du coiffeur.`,
    `Le retour du père du narrateur après un mois d'absence`  
]