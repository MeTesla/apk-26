const bamoeuvre =require('./bamoeuvre.js')
const bamqcm =require('./bamqcm.js')
const bamvf =require('./bamvf.js')
const bamordreph =require('./bamordreph.js')
const bamordreev =require('./bamordreev.js')
const bamvide =require('./bamvide.js')
const bamresume =require('./bamresume.js')
const antigoneoeuvre =require('./antigoneoeuvre.js')
const antigoneqcm =require('./antigoneqcm.js')
const antigonevf =require('./antigonevf.js')
const antigoneordreph =require('./antigoneordreph.js')
const antigoneordreev =require('./antigoneordreev.js')
const antigonevide =require('./antigonevide.js')
const antigoneresume =require('./antigoneresume.js')
const djcoeuvre =require('./djcoeuvre.js')
const djcvide =require('./djcvide.js')
const djcordreev =require('./djcordreev.js')
const djcordreph =require('./djcordreph.js')
const djcqcm =require('./djcqcm.js')
const djcvf =require('./djcvf.js')
const djcresume =require('./djcresume.js')

module.exports={bamoeuvre,
bamqcm,
bamvf,
bamordreph,
bamordreev,
bamvide,
bamresume,
antigoneoeuvre,
antigoneqcm,
antigonevf,
antigoneordreph,
antigoneordreev,
antigonevide,
antigoneresume,
djcoeuvre,
djcvide,
djcordreev,
djcordreph,
djcqcm,
djcvf,
djcresume,}
