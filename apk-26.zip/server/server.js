const express = require('express')
const mongoose = require('mongoose')
const EleveModel = require('./EleveModel')
const jwt = require('jsonwebtoken')
const cors = require('cors')
const app=express()
app.use(cors())
app.use(express.json())

const {bamvf,
bamoeuvre,
bamresume,
bamqcm,
bamordreph,
bamordreev,
bamvide,
antigonevf,
antigoneoeuvre,
antigoneresume,
antigoneqcm,
antigoneordreph,
antigoneordreev,
antigonevide,
djcvf,
djcoeuvre,
djcresume,
djcqcm,
djcordreph,
djcordreev,
djcvide} = require('./bd/data');

const postEmail = require('./utils');

const SECRET_KEY='mkljaz_çè(__j'
const URL = `mongodb+srv://pookarim:UJyLoPjoP0UjbruY@notesapp.prtaxaf.mongodb.net/test?ssl=true&authSource=admin&w=majority`
// Generate TOKEN
function generateToken(id){
    return jwt.sign({id}, SECRET_KEY,{expiresIn:'1m'})
} 
// Ajouter au menu Boutton : demander 15 min. 
// verifier ne backend (date dernier token =/= date demande token)

//-------Créer compte
app.post('/creer-compte', async(req, res)=>{
    const {nom, prenom, email, tel}=req.body
       
    const token= await generateToken(email)
    
    const today= new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(today.getDate() + 1)
    //futureDate.setMinutes(now.getMinutes() + minutesToAdd);
    
    const eleve = new EleveModel({nom, prenom, email, tel:parseInt(tel), token})
    await eleve.save()

    //await postEmail(req, res, token)
    res.json({eleve})
    
    //Créer user DB (nom, tel, email, token, imageProfile)
})

//MIDDLEWARE
const auth = async(req, res, next)=>{
    const {authorization} = req.headers    
    if(!authorization) {
        console.log('Authorization non accordée');
        return res.json('accès interdit')
    }

    try {
       const isValidToken = jwt.verify(authorization, SECRET_KEY)
        if(!isValidToken) return res.json('Votre session a pris fin.')
        req.user = authorization  
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json('Le token a expiré, veuillez vous reconnecter.');
        } else {
            return res.status(401).json('Token invalide');
    }
    }
    
    next()
}

function prepareData( exo){
    switch (exo) {
        case 'bamvf': return bamvf; break;    
        case 'bamoeuvre': return bamoeuvre;    break;
        case 'bamresume': return bamresume;      break;
        case 'bamqcm': return bamqcm;        break;        
        case 'bamordreph': return bamordreph;      break;        
        case 'bamordreev': return bamordreev;        break;        
        case 'bamvide': return bamvide;       break;  

        case 'antigonevf': return antigonevf; break;    
        case 'antigoneoeuvre': return antigoneoeuvre;    break;
        case 'antigoneresume': return antigoneresume;      break;
        case 'antigoneqcm': return antigoneqcm;        break;        
        case 'antigoneordreph': return antigoneordreph;      break;        
        case 'antigoneordreev': return antigoneordreev;        break;        
        case 'antigonevide': return antigonevide;       break;                
        
        case 'djcvf': return djcvf; break;    
        case 'djcoeuvre': return djcoeuvre;    break;
        case 'djcresume': return djcresume;      break;
        case 'djcqcm': return djcqcm;        break;        
        case 'djcordreph': return djcordreph;      break;        
        case 'djcordreev': return djcordreev;        break;        
        case 'djcvide': return djcvide;       break;        
        
        
        default:
            break;
    }
}

app.get('/', auth, (req, res)=>{
    const {exo}=req.query   
    console.log(req.authorization);
    
    const data = prepareData(exo)
    res.json(data)
})

mongoose.connect(URL)
    .then(() => {
        console.log('Connexion à la base de données réussie !');
    })
    .catch(err => {
        console.error('Erreur de connexion à la base de données :', err);
    });


app.listen('3000',()=>{
    console.log('Connected to server');    
})