export const data=[
 'La description de dar chouafa',
 'Une séance au bain maure',
 'La dispute de lalla Zoubida et Rahma'
 ]
