export const tabPhrases = [
    "Sidi Mohammed est un enfant solitaire",
    "Le narrateur n'aime pas le bain maure",
    "L'enfant décrit dar chouafa",
    "Sidi Mohammed parle d'une séance au bain maure", 
    "La chouafa s'appelle tante Kanza", 
    "Sidi Mohammed compare le bain maure à l'enfer"
]