export let pairs=[
    {'mot':'aller', 'syn':'se rendre'},
    {'mot':'se tromper', 'syn': 'faire erreur'},
    {'mot': 'quitter', 'syn': "s'en aller"},
    {'mot':'travail', 'syn' :'boulot'} ,
    {'mot':'avoir', 'syn' :'posséder'}, 
    {'mot':'numérique', 'syn' :'digital'}]
